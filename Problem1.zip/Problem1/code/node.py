class Node:
    def __init__(self,index=None,next=None,distance=None,root=None):
        self.index=index  #node ID
        self.distance=distance #the distance between this node and the host node
        self.next = next #point at the next node
        self.root=root

