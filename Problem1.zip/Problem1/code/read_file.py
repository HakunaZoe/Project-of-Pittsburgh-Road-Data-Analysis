import pandas as pd
import numpy as np
from collections import defaultdict
from node import *
def read_to_dictionary(file1,file2):
    data_csv1=pd.read_csv(file1,header=None)
    data1=np.array((data_csv1[1:])) #remove the header
    data_csv2=pd.read_csv(file2,header=None)
    data2=np.array((data_csv2[1:]))
    G=defaultdict(list)
    V=defaultdict(list)
    G1=defaultdict(list)

    """
    1.dictionary-V
    put the nodes of G2 into dictionary-V
        key:index(row[3])
        value:[]
            value[0]:node name(row[0])  #the node's name in G2
            value[1]:the node's name in G1(default value is -1) if the value is -1,  the node is not in G1
    iterate the nodes in G1:if row[3] is not in the dictionary V, we add it to the dictionary
            key:row[3]
            value:[]
                value[0]:node name(len(dictionary)+1) #the name in G2
                value[1]:node name(row[0]) #the name in G1
    """
    for row in data2:
        if row[3] not in V:
            V[row[3]]=[int(row[0]),-1]
        G[int(row[0])].append([int(row[1]),float(row[2])])
    for row in data1:
        G1[int(row[0])]=row[3]
        N2=len(V)
        if row[3] not in V:
            V[row[3]]=[N2,int(row[0])]
    print(len(V))
    """
    store the adjacent information in G
        key:node name
        value:[]
            value[0]:[adjacent node name1,distance]
            value[1]"[adjacent node name2,distance]
    """
    for row in data1:
        """
        V[row[3]][0]:store the name of nodes of G2 whose index is row[3] in G1
        row[1]:the name of adjacent node in G1
        G1[row[1]]:adjacent node's index
        V[G1[row[1]][0]]:adjacent node's name in G2
        """
        G[V[row[3]][0]].append([V[G1[int(row[1])]][0],float(row[2])])
    """
    for x,y in G.items():
        print(x,y)
    """
    return G

def dictionary_to_array(G): 
    n=len(G)
    M=[[0 for _ in range(n) ] for _ in range(n)]
    for node in G:
        for adjacent_node in G[node]:
            M[node][adjacent_node[0]]=adjacent_node[1]
    return M

def dictionary_to_linklist(G):
    Graph={}
    for index in G:
        host_node=Node(index=index)
        Graph[index] = host_node
        for adjacent_index in G[index]:
            new_node=Node(index=adjacent_index[0],distance=adjacent_index[1])
            host_node.next=new_node
            host_node=new_node
    return Graph
