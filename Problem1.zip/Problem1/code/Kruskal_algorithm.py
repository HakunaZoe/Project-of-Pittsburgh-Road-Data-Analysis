from collections import defaultdict
import pandas as pd
def kruskal_2_array(M):
    #find the shortest edge
    F=[]#the set of edges
    n=len(M)# the number of nodes
    G=defaultdict()#(i,j):distance
    for i in range(n):
        for j in range(n):
            if M[i][j]!=0 and i<j:
                G[(i,j)]=M[i][j]
    root=[-1 for _ in range(n)] #record the name of each root node
    E = [[k, v] for k, v in sorted(G.items(), key=lambda item: item[1])]
    #E=[[(0,1),1],[(2,3),1],[(4,5),1],[(0,2),2],[(1,5),2],[(3,4),2],[(2,5),3]]
    #root=[-1 for _ in range(6)]
    for edge in E:
        #print('********')
        #print(edge,root[edge[0][0]],root[edge[0][1]])
        if root[edge[0][0]]==-1 and root[edge[0][1]]==-1: #i,j第一次添加：以i为根节点，把i,j的根节点都保存为i
            root[edge[0][0]]=edge[0][0]
            root[edge[0][1]]= edge[0][0]
        elif root[edge[0][0]]!=-1 and root[edge[0][1]]!=-1 and root[edge[0][1]]==root[edge[0][0]]:#i,j都不是第一次添加且已经在一个连通量里面：不添加，跳过
            continue;
        elif root[edge[0][0]]==-1 and root[edge[0][1]]!=-1:#i第一次添加：把i添加到j的连通量里面
            root[edge[0][0]]=root[edge[0][1]]

        elif root[edge[0][1]]==-1 and root[edge[0][0]]!=-1:#j第一次添加：把j添加到i的连通量里面
            root[edge[0][1]]=root[edge[0][0]]
        elif root[edge[0][0]]!=-1 and root[edge[0][1]]!=-1 and root[edge[0][1]]!=root[edge[0][0]]:#i,j在不同的连通量里面：把他们连在一起，把所有属于j连通量的节点的根节点都改为i的根节点
            index=[]
            temp=root[edge[0][0]]
            for i in range(len(root)):
                #print(i,root[i],root[edge[0][0]],root[edge[0][1]])
                if root[i]==root[edge[0][1]]:
                    index.append(i)
            for i in range(len(index)):
                root[index[i]]=temp
        F.append(edge)
        #print(root)
    return F
def kruskal_linkedlist(Graph):
    n=len(Graph)
    G = defaultdict()  # (i,j):distance
    F = []  # the set of edges
    for i in range(n):
        p=Graph[i]
        while(p.next):
            p = p.next
            G[(i,p.index)]=p.distance
    E=[[k,v] for k, v in sorted(G.items(), key=lambda item: item[1])]
    for edge in E:
        if not Graph[edge[0][0]].root and not Graph[edge[0][1]].root:#i,j第一次添加：以i为根节点，把i,j的根节点都保存为i
            Graph[edge[0][0]].root=edge[0][0]
            Graph[edge[0][1]].root= edge[0][0]
        elif Graph[edge[0][0]].root==Graph[edge[0][1]].root: #i,j都不是第一次添加且已经在一个连通量里面：不添加，跳过
            continue;
        elif not Graph[edge[0][0]].root:#i第一次添加：把i添加到j的连通量里面
            Graph[edge[0][0]].root=Graph[edge[0][1]].root

        elif not Graph[edge[0][1]].root:#j第一次添加：把j添加到i的连通量里面
            Graph[edge[0][1]].root=Graph[edge[0][0]].root

        else:#i,j在不同的连通量里面：把他们连在一起，把所有属于j连通量的节点的根节点都改为i的根节点
            index=[]
            temp=Graph[edge[0][0]]
            for i in range(n):
                if Graph[i].root==Graph[edge[0][1]].root:
                    index.append(i)
            for i in range(len(index)):
                Graph[index[i]]=temp
        F.append(edge)
    return F

def print_result(F):
    dict = {"Node1": [],
            "Node2": [],
            "Distance": []}
    for i in range(len(F)):
        dict['Node1'].append(F[i][0][0])
        dict['Node2'].append(F[i][0][1])
        dict['Distance'].append(F[i][1])
    result = pd.DataFrame(dict)
    print('**********output***************')
    print(result)
    print('*******************************')
    print(f"the total distance is : {result['Distance'].sum()}")







