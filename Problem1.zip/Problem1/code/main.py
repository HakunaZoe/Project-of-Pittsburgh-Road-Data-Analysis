"""
object:
(1)merge two input graphs into one graph,called G
(2)create a new adjacency matrix in two-dimensions
(3)create a new adjacency matrix in linked-list
(4)implement Kruskal's algorithm to find a minimum-spanning tree in two-dimensions
(5)implement Kruskal's algorithm to find a minimum-spanning tree in linked-list
(6)Print the computed minimum-spanning tree in(4) and (5):
(7)Report on the memory usage by each of the two data structures.
"""
import os
import psutil;
from read_file import *
from Kruskal_algorithm import *

game_is_on=True
while game_is_on:
    memory_before_used = psutil.Process(os.getpid()).memory_info().rss / 1024 ** 2
    G = read_to_dictionary('Project3_G2_Data.csv', 'Project3_G1_Data.csv')
    print(f'welcome to project3\n'
          f'if you want to run Kruskal algorithm in two-dimensions,please input1\n'
          f'if you want to run Kruskal algorithm in linked-list,please input2\n'
          f'if you want to quit,please input other numbers:)')
    user_input=input()
    if user_input=='1':
        M=dictionary_to_array(G) #create a new adjacency matrix in two-dimensions
        print_result(kruskal_2_array(M)) #implement Kruskal's algorithm to find a minimum-spanning tree in two-dimensions
    elif user_input=='2':
        Graph=dictionary_to_linklist(G)#create a new adjacency matrix in linked-list
        print_result(kruskal_linkedlist(Graph))
    else:
        game_is_on=False
        print('good bye!!!')
    memory_after_used = psutil.Process(os.getpid()).memory_info().rss / 1024 ** 2
    print(f'the memory used is: {memory_after_used - memory_before_used} MB')





