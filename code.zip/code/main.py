from read_file import *
from K_Means import *
import matplotlib.pyplot as plt
game_is_on=True
while game_is_on:
    print(f'welcome to algorithm project3: k-means!!!!\n'
          f'if you want to run k-means on the test case,please input1:\n'
          f'if you want to run k-means on the power consumption dataset,please input2:\n'
          f'you can also input any other numbers to quit,thanks:)')
    user_input=int(input())
    if user_input==1:
        X, Y = read_file_test('Project3_Test_Case.csv')
        plot_testcase(X,Y)
        k = 2
        k_means(X, k)
    if user_input==2:
        X = read_file_power('Project3_Power_Consumption.csv')
        k = 2
        k_means(X,k)
        # losses=[]
        # for k in range(3,21):
        #     print(f"k={k}!!!!\n")
        #     losses.append(k_means(X,k))
        # print(losses)


        # plot
        # indexes=[i for i in range(3,21)]
        # plt.plot(indexes,losses,'o')
        # plt.title('the loss of each value of k')
        # plt.xticks(range(3,21))
        # plt.xlabel('k')
        # plt.ylabel('loss')
        # plt.show()


