import random
random.seed=123
import math
import numpy as np
from collections import Counter
import matplotlib.pyplot as plt
np.set_printoptions(suppress=True)
def distance_i_u(X,i,u):
    summ=0
    for v in range(len(X[0])):
        summ+=(X[i][v]-u[v])**2
    return math.sqrt(summ)
def calculate_the_loss(X,c,U):
    summ=0
    for i in range(len(X)):
        summ+=distance_i_u(X,i,U[c[i]])**2
    return summ/len(X)
def plot_testcase(X,c):
    X1=X[:,0]
    X2=X[:,1]
    plt.plot(X1,X2,'o')
    plt.show()


def k_means(X,k):
    #randomly initialization
    n=len(X)
    U=[X[j] for j in random.sample(range(n),k)]#the centroids
    c=[-1 for _ in range(n)] #store the class number of each node
    stop_count=50
    #go through all the dataset
    count=0
    loss=float('inf')
    while count<stop_count:
        print(f"this is the time of {count + 1}:\n")
        for p in range(k):
              print(f" the coordinate of class {p+1} is {U[p]},\n")
        #color each of the points by determining which class it belongs to(which centroid it belongs to)
        for i in range(n):
            minn_distance=float('inf')
            minn_index_of_class=-1
            for j in range(k):
                D_i_j=distance_i_u(X,i,U[j])
                if D_i_j<minn_distance:
                    minn_distance=D_i_j
                    minn_index_of_class=j
            c[i]=minn_index_of_class
        print(f'the number of each class: {Counter(c)}')
        #calculate the loss
        loss_now=calculate_the_loss(X,c,U)
        temp=abs(loss-loss_now)/(loss*100)
        print(f'the loss: {loss_now}')
        if temp<0.0000001:
            print(f'Since the value of loss has no further changes at the {count+1} time,loop out!!!')
            break;
        else:
            loss=loss_now


        #update the new costerids:
        U=[]
        for j in range(k):
            temp=[]
            for v in range(len(X[0])):
                avg = 0;
                count_class=0
                for i in range(n):
                    if c[i]==j:
                        count_class+=1
                        avg+=X[i][v]
                avg=avg/count_class
                temp.append(avg)
            U.append(temp)
        count+=1
    return loss_now



