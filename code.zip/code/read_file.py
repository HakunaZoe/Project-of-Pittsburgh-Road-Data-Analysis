import pandas as pd
import numpy as np
def read_file_test(file):
    data_csv = pd.read_csv(file)
    X=np.array(pd.DataFrame(data_csv[['X1','X2']]))
    Y=np.array(pd.DataFrame(data_csv['Y']))
    return [X,Y]

def read_file_power(file):
    data_csv = pd.read_csv(file)
    X=np.array(pd.DataFrame(data_csv))
    return X
"""
def normalization(X):
    for v in range(len(X[0])):
        maxx=np.max(X[:,v])
        minn=np.min(X[:,v])
        for i in range(len(X)):
            X[i][v]=(X[i][v]-minn)/(maxx-minn)
    return X
"""