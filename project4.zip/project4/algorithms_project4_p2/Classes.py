class Node:
    def __init__(self,level):
        self.level=level
        self.bound=0
        self.visited=[]
class PriorityQueue(object):
    def __init__(self):
        self.queue = []
        self.index = 0
    def push(self, node):
        self.queue.append(node)
        self.queue.sort(key=lambda x:x.bound)
    def pop(self):
        q=self.queue.pop(0)
        return q
    def size(self):
        return len(self.queue)
    def empty(self):
        return True if not self.queue else False