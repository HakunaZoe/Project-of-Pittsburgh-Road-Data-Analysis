import pandas as pd
import numpy as np
def read_2_array(file):
    data_csv=pd.read_csv(file,header=None)
    data=data_csv[1:]
    data=np.array((data))
    n=int(data[-1][0])+1
    M=np.zeros((n,n))
    for row in data:
        M[int(row[0])][int(row[1])]=float(row[2])
    return M
def read_1_array(file):
    #read the file and store it to be in 1-d array
    M=[]
    W=read_2_array(file)
    n=len(W)
    for i in range(len(W)):
        for j in range(i):
            M.append(W[i][j])
    return [M,n]


