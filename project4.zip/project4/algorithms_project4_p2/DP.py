def find_distance(i, V,W,dp):
    if (i, str(V)) in dp:
        return dp[(i, str(V))]
    else:
        minn_distance = float('inf')
        minn_route=[]
        for n in range(len(V)):
            if W[i][V[n]] == 0:
                continue;
            V_ = V[:n] + V[n + 1:] #record the nodes which are left
            if (V[n], str(V_)) in dp:
                temp_distance = dp[(V[n], str(V_))][0] + W[i][V[n]]
                temp_route = [V[n]]+dp[(V[n], str(V_))][1]
            else:
                find_distance(V[n], V_,W,dp) 
                temp_distance = dp[(V[n], str(V_))][0] + W[i][V[n]]
                temp_route = [V[n]]+dp[(V[n], str(V_))][1]

            if temp_distance < minn_distance:
                minn_distance = temp_distance
                minn_route = temp_route
    dp[(i, str(V))] = [minn_distance, minn_route]
    return dp[(i, str(V))]


def find_distance_1_array(i, V,M,dp): #same as 2-array version
    if (i, str(V)) in dp:
        return dp[(i, str(V))]
    else:
        minn_distance = float('inf')
        minn_route=[]
        for n in range(len(V)):
            if i>V[n]:
                value=i*(i-1)//2+V[n]
            else:
                value=V[n]*(V[n]-1)//2+i
            if M[value] == 0:
                continue;
            V_ = V[:n] + V[n + 1:]
            if (V[n], str(V_)) in dp:
                temp_distance = dp[(V[n], str(V_))][0] + M[value]
                temp_route = [V[n]]+dp[(V[n], str(V_))][1]
            else:
                find_distance_1_array(V[n], V_,M,dp)
                temp_distance = dp[(V[n], str(V_))][0] + M[value]
                temp_route = [V[n]]+dp[(V[n], str(V_))][1]

            if temp_distance < minn_distance:
                minn_distance = temp_distance
                minn_route = temp_route
    dp[(i, str(V))] = [minn_distance, minn_route]
    return dp[(i, str(V))]
