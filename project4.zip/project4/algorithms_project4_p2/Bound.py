from Classes import Node,PriorityQueue
def bound(u,W):
    #result:the value of bound:the sum of the minimums-a lower bound on the length of a tour
    #since a tour must leave every vertex exactly once
    n=len(W)
    result=0
    for i in range(1,len(u.visited)):
        result+=W[u.visited[i-1]][u.visited[i]]
    non_visited=list(set([x for x in range(n)]) ^set(u.visited))
    distance_i=[u.visited[-1]]+non_visited
    distance_j=non_visited+[0]
    summ_minn=0
    for i in distance_i:
        temp_minn=float('inf')
        for j in distance_j:
            if i!=j and W[i][j]<temp_minn and W[i][j]>0:
                temp_minn=W[i][j]
        summ_minn +=temp_minn
    return summ_minn
def tsp(W):
    n=len(W)
    PQ=PriorityQueue()
    v=Node(0)
    v.visited.append(0)
    v.bound=bound(v,W)
    minn_distance=float('inf')
    minn_path=[]
    PQ.push(v)
    while not PQ.empty():
        v=PQ.pop()
        if v.bound<minn_distance:
            non_visited=list(set([x for x in range(n)])^set(v.visited))
            for j in range(len(non_visited)):
                if W[v.visited[-1]][non_visited[j]]!=0:
                    u=Node(v.level+1)
                    u.visited=v.visited+[non_visited[j]]
                    if u.level==n-1:
                        distance=0
                        for i in range(1,len(u.visited)):
                            distance+=W[u.visited[i-1]][u.visited[i]]
                        distance+=W[u.visited[i]][0]
                        if distance<minn_distance:
                            minn_distance=distance
                            minn_path=u.visited+[0]
                    else:
                        u.bound=bound(u,W)
                        if u.bound<minn_distance:
                            PQ.push(u)
    print(f"the minmum distance is: {minn_distance}")
    print(f"the result route is:")
    for i in range(len(minn_path)):
        if i==len(minn_path)-1:
            print(minn_path[i],end='')
        else:
            print(minn_path[i],end='->')


def bound_1_array(u, M, n):
    # result:the value of bound:the sum of the minimums-a lower bound on the length of a tour
    # since a tour must leave every vertex exactly once
    result = 0
    for i in range(1, len(u.visited)):
        x = u.visited[i - 1]
        y = u.visited[i]
        value = calculate(x, y)
        result += M[value]
    non_visited = list(set([x for x in range(n)]) ^ set(u.visited))
    distance_i = [u.visited[-1]] + non_visited
    distance_j = non_visited + [0]
    summ_minn = 0
    for i in distance_i:
        temp_minn = float('inf')
        for j in distance_j:
            value = calculate(i, j)
            if i != j and M[value] < temp_minn and M[value] > 0:
                temp_minn = M[value]
        summ_minn += temp_minn
    return summ_minn


def calculate(x, y):
    if x > y:
        value = x * (x - 1) // 2 + y
    else:
        value = y * (y - 1) // 2 + x
    return value


def tsp_1_array(M, n):
    PQ = PriorityQueue()
    v = Node(0)
    v.visited.append(0)
    v.bound = bound_1_array(v, M, n)
    minn_distance = float('inf')
    minn_path = []
    PQ.push(v)
    while not PQ.empty():
        v = PQ.pop()
        if v.bound < minn_distance:
            non_visited = list(set([x for x in range(n)]) ^ set(v.visited))
            for j in range(len(non_visited)):
                x = v.visited[-1]
                y = non_visited[j]
                value = calculate(x, y)
                if M[value] != 0:
                    u = Node(v.level + 1)
                    u.visited = v.visited + [non_visited[j]]
                    if u.level == n - 1:
                        distance = 0
                        for i in range(1, len(u.visited)):
                            x = u.visited[i - 1]
                            y = u.visited[i]
                            value = calculate(x, y)
                            distance += M[value]

                        x = u.visited[i]
                        distance += M[x * (x - 1) // 2]
                        if distance < minn_distance:
                            minn_distance = distance
                            minn_path = u.visited + [0]
                    else:
                        u.bound = bound_1_array(u, M, n)
                        if u.bound < minn_distance:
                            PQ.push(u)
    print(f"the minmum distance is: {minn_distance}")
    print(f"the result route is:")
    for i in range(len(minn_path)):
        if i == len(minn_path) - 1:
            print(minn_path[i], end='')
        else:
            print(minn_path[i], end='->')