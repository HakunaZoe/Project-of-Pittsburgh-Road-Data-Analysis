from read_file import *
from DP import *
from Bound import *

print(f"welcome project2:problem2!!!\n"
      f"if you want to use 2-array-dp-program,please input 1\n"
      f"if you want to use 2-array-bound-program,please input2\n"
      f"if you want to use 1-array-dp-program,please input3\n"
      f"if you want to use 1-array-bound-program,please input4")
user=input()
if user=='1':
    W = read_2_array('Project 4_Problem 2_InputData.csv')
    n=len(W)
    INF=float('inf')
    dp={}#(i,V)=>[distance,index_K]
    V=[ i for i in range(1,n)]
    tot_distance=0
    for i in range(n):
        if W[i][0]==0:
            dp[(i,'[]')]=[INF,[0]]
        else:
            dp[(i,'[]')]=[W[i][0],[0]]
    result=find_distance(0,V,W,dp)
    result_distance=result[0]
    result_route=result[1][::-1]+[0]
    print(f"the minimum distance is: {result_distance}")
    print(f"the result route is:\n")
    for i in range(len(result_route)):
        if i==len(result_route)-1:
            print(result_route[i],end='')
        else:
            print(result_route[i],end='->')
if user=='2':
    W = read_2_array('Project 4_Problem 2_InputData.csv')
    tsp(W)
if user=='3':
    M,n=read_1_array('Project 4_Problem 2_InputData.csv')
    INF = float('inf')
    dp = {}  # (i,V)=>[distance,index_K]
    V = [i for i in range(1, n)]
    tot_distance = 0
    for i in range(1,n):
        value = i * (i - 1) // 2
        if M[value] == 0:
            dp[(i, '[]')] = [INF, [0]]
        else:
            dp[(i, '[]')] = [M[value], [0]]
    result = find_distance_1_array(0, V, M, dp)
    result_distance = result[0]
    result_route = result[1][::-1] + [0]
    print(f"the minimum distance is: {result_distance}")
    print(f"the result route is:")
    for i in range(len(result_route)):
        if i == len(result_route) - 1:
            print(result_route[i], end='')
        else:
            print(result_route[i], end='->')
if user=='4':
    M,n=read_1_array('Project 4_Problem 2_InputData.csv')
    tsp_1_array(M, n)