from read_File import *
from floyd import *
M=read_to_array("Project 4_Problem 1_InputData.csv")
result=find_centrality(Floyd_array(M))
result=pd.Series(result).sort_values(ascending=False).index[:20]
print(f"the top 20 betweenness centrality vertices are:\n")
print(result)
