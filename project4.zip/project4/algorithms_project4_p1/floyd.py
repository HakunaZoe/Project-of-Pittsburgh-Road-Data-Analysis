def route_total_distance(s,e,vertex_matrix,result,total_distance,M):#print out the route with DFS

    if vertex_matrix[s][e]==-1:
        return
    route_total_distance(s,vertex_matrix[s][e],vertex_matrix,result,total_distance,M)
    result.append(vertex_matrix[s][e])
    total_distance+=M[s][e]
    route_total_distance(vertex_matrix[s][e],e,vertex_matrix,result,total_distance,M)
    return result
def route_count(s,e,vertex_matrix,result):#print out the route with DFS
    if vertex_matrix[s][e]==-1:
        return
    route_count(s,vertex_matrix[s][e],vertex_matrix,result)
    result[vertex_matrix[s][e]] +=1
    route_count(vertex_matrix[s][e],e,vertex_matrix,result)
    return result
def Floyd_array(M):
    n=len(M)
    vertex_matrix=[[-1 for i in range(n)] for j in range(n)]
    for k in range(n):#set k as the inner node to update M
        print(k)
        for i in range(n):
            for j in range(n):
                if M[i][k]>0 and M[k][j]>0 and M[i][k]+M[k][j]>0 and (M[i][j]>M[i][k]+M[k][j]  or M[i][j]==0):
                    M[i][j]=M[i][k]+M[k][j]
                    vertex_matrix[i][j]=k #mark the inner node between i and j
    print('finished')
    return vertex_matrix

def find_centrality(vertex_matrix):
    n=len(vertex_matrix)
    result=[0 for _ in range(n)]
    #use all nodes as the source and the other all nodes as the dest, memorize the count
    for s in range(n):
        print(s)
        for e in range(n):
            route_count(s,e,vertex_matrix,result)
    return result

















