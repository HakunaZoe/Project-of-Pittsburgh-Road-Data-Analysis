import numpy as np
import pandas as pd
def read_to_array(file):
    data_csv=pd.read_csv(file,header=None)
    data = np.array((data_csv[1:]))
    n = int(data[-1][0]) + 1
    M = np.zeros((n, n))  # initial the adjacent matrix
    for row in data:
        M[int(row[0])][int(row[1])] = int(row[2])
    return M

