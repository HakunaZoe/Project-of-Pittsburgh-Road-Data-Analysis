#!/usr/bin/env python
# coding: utf-8

# #### 

# In[4]:


#use Node to package the coordinates in each dimention, and let index to be the number of queen
class Node():
    def __init__(self,index=-1,x=-1,y=-1,z=-1):
        self.index=index
        self.x=x
        self.y=y
        self.z=z
def promissing(node,queue): #judge if the node of index i has collisions with nodes with index before i
    for node_visited in queue:
        if node.x==node_visited.x and node.y==node_visited.y:
            return False
        if node.y==node_visited.y and node.z==node_visited.z:
            return False
        if node.z==node_visited.z and node.x==node_visited.x:
            return False
        #diagnal collision
        if node.x==node_visited.x and (abs(node.y-node_visited.y)==abs(node.z-node_visited.z)):
            return False
        if node.y==node_visited.y and (abs(node.z-node_visited.z)==abs(node.x-node_visited.x)):
            return False
        if node.z==node_visited.z and (abs(node.x-node_visited.x)==abs(node.y-node_visited.y)):
            return False    
        if abs(node.x-node_visited.x)==abs(node.y-node_visited.y)==abs(node.z-node_visited.z):
            return False
    return True
def n_queens(node,n):
    global count,queue
    if node.index==n-1:
        count+=1
    else:   
        for x in range(n):
            if x<node.x:continue
            for y in range(n):
                if x==node.x and y<node.y:continue
                for z in range(n):
                    if x==node.x and y==node.y and z<node.z:continue
                    new_node=Node(index=node.index+1,x=x,y=y,z=z)
                    if promissing(new_node,queue):
                        queue.append(new_node)
                        n_queens(new_node,n)
                        if len(queue)>0:
                            queue.pop()

for i in range(2,6):
    count=0
    queue=[]
    n_queens(Node(),i)
    print(f"the number of queen is:{i}, and the result is: {count}")



# In[ ]:




