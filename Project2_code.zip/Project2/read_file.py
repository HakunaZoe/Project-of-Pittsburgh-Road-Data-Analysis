import numpy as np
import pandas as pd
from node import *
def read_to_array(file):
    data_csv=pd.read_csv(file,header=None)
    data=np.array((data_csv[1:]))
    n=int(data[-1][0])+1
    M=np.zeros((n,n))#initial the adjacent matrix
    for row in data:
        M[int(row[0])][int(row[1])]=int(row[2])
    return M



def read_to_link(file):
    Graph={};#store all the links
    data_csv=pd.read_csv(file)
    for i in range(len(data_csv)):
        id=data_csv["NodeID"][i]
        adjacent_id=data_csv['ConnectedNodeID'][i]
        distance=data_csv['Distance'][i]
        new=True
        for i in range(len(Graph)):
            host_node=Graph[i]
            if host_node.index==id:#the node has been stored in the Graph
                new=False
                p=host_node.next
                while(p.next!=None):
                    p=p.next
                p.next=Node(index=adjacent_id,distance=distance,inner_node=host_node.index)
        if new==True:
            host_node = Node(index=id,distance=0)
            new_node = Node(index=adjacent_id,distance=distance,inner_node=host_node.index)
            host_node.next = new_node
            Graph[id]=host_node
    return Graph












read_to_array('Project2_Input_File3.csv')