import matplotlib.pyplot as plt
def plot(times,i):
    if i==1:
        plt.title('performance of dijkstra algorithm-2 array')
    elif i==2:
        plt.title('performance of dijkstra algorithm-linkedlist')
    elif i==3:
        plt.title('performance of floyd algorithm-2 array')

    elif i==4:
        plt.title('performance of floyd algorithm-linkelist')
    x_data=times.keys()
    y_data=times.values()
    plt.bar(x=x_data,height=y_data)
    plt.xlabel('file')
    plt.ylabel('time /s')
    plt.xticks(range(1,11))
    for a,b in zip(x_data, y_data):
        plt.text(a,b,
                b,
                 ha='center',
                va='bottom',
                )
    plt.grid()
    plt.show()