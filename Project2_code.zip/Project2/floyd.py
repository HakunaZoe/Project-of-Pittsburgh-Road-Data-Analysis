from node import *
def route(s,e,vertex_matrix,result,total_distance,M):#print out the route with DFS

    if vertex_matrix[s][e]==-1:
        return
    route(s,vertex_matrix[s][e],vertex_matrix,result,total_distance,M)
    result.append(vertex_matrix[s][e])
    total_distance+=M[s][e]
    route(vertex_matrix[s][e],e,vertex_matrix,result,total_distance,M)
    return [result,total_distance]
def Floyd_array(M,s,e):
    n=len(M)
    vertex_matrix=[[-1 for i in range(n)] for j in range(n)]
    for k in range(n):#set k as the inner node to update M
        for i in range(n):
            for j in range(n):
                if M[i][k]>0 and M[k][j]>0 and M[i][k]+M[k][j]>0 and (M[i][j]>M[i][k]+M[k][j]  or M[i][j]==0):
                    M[i][j]=M[i][k]+M[k][j]
                    vertex_matrix[i][j]=k #mark the inner node between i and j
    print(f"begin node: {s}")
    print(f"end node: {e}")
    result_and_distance=route(s,e,vertex_matrix,[],0,M)
    #print(f"passing route: {[s]+result_and_distance[0]+[e]}")
    #print(f"total distance: {int(result_and_distance[1])}")

def route_link(Graph,s,e,result):#result[s]
    node=Graph[s].next
    while(node):
        if node.index==e:
            if node.inner_node==s:
                return result
            else:
                route_link(Graph,s,node.inner_node,result)
                result.append(node.inner_node)
                route_link(Graph,node.inner_node,e,result)
        node=node.next
    return result

def Floyd_link(Graph,s,e):
    n=len(Graph)
    for k in range(n):
        node_1=Graph[k].next #distance=inner_node-node_1
        while(node_1):
            node_2 = Graph[k].next  # distance=inner_node-node_2
            while(node_2):
                if node_1.index==node_2.index:
                    node_2=node_2.next;
                    continue;
                #print(node_1.index,node_2.index)
                ad_node_1=Graph[node_1.index].next #ad_node_1-node_1
                node_2_in_node_1=False;
                while(ad_node_1):
                    if ad_node_1.index==node_2.index:
                        node_2_in_node_1=True
                        if ad_node_1.distance>node_2.distance+node_1.distance:
                            ad_node_1.distance=node_2.distance+node_1.distance
                            ad_node_1.inner_node=k
                    ad_node_1=ad_node_1.next
                if node_2_in_node_1 == False:
                    node_i = Graph[node_1.index].next
                    while(node_i.next):
                        node_i=node_i.next
                    node_i.next=Node(index=node_2.index,next=None,distance=node_2.distance+node_1.distance,inner_node=k)
                node_2=node_2.next
            node_1=node_1.next

    result=[s]
    route_link(Graph,s,e,result)
    result.append(e)
    print(f"begin node: {s}")
    print(f"end node: {e}")
    print(f"passing route: {result}")
    node=Graph[s]
    while(node):
        if node.index==e:
            print(f'total distance: {node.distance}')
        node=node.next












