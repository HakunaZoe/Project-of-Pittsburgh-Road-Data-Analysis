from node import *
import sys
sys.setrecursionlimit(100000)
def Dijkstra_array(s,e,visited,visited_distance,M,visited_routes):
    #print(s,e,visited,visited_distance)
    if len(visited)==1:
        minn=1000000000;
        for j in range(len(M[s])):
            if M[s][j]!=0 and M[s][j]<minn:
                minn=M[s][j];
                node=j
        visited.append(node) #append the node which has been visited
        visited_distance.append(minn) #append the minimum distance between s and node
        visited_routes[node]=[s,node]
    else:
        minn=100000000;
        node=-1;
        pos_node=-1;
        for j in range(len(M)):
            if j not in visited and j !=s:
                for i in range(len(visited)):
                    if M[visited[i]][j]!=0 and M[visited[i]][j]+visited_distance[i]<minn:
                        minn=M[visited[i]][j]+visited_distance[i];
                        node=j
                        pos_node=visited[i];
        if node!=-1 and pos_node!=-1:# to make sure the node is useful
            visited.append(node)
            visited_distance.append(minn)
            #print(visited_routes[pos_node])
            visited_routes[node]=visited_routes[pos_node]+[node] #node can be appended to the shortest route
    if node==e:
        total_distance=0
        for i in range(len(visited_routes[e])-1):
            total_distance +=M[visited_routes[e][i]][visited_routes[e][i+1]]
        print(f"begin node: {s}")
        print(f"end node: {e}")
        print(f"passing rote: {visited_routes[e]}")
        print(f"total distance: {int(total_distance)}")
        return;
    Dijkstra_array(s,e,visited,visited_distance,M,visited_routes)





def Dijkstra_Link(s,e,visited,visited_routes,Graph,total_distance):
    if len(visited) == 1:
        minn = 100000000;
        p = Graph[s];  # set the node
        while (p.next != None):
            p = p.next
            if p.distance < minn:
                minn = p.distance
                node = p;
        visited.append(node)
        new_node=Node(index=node.index,distance=minn)
        visited_routes[new_node.index]=[s,new_node.index]#store the index and distance
        if node.index==e:
            print('result:::::')
            p=visited_routes;
            while(p):
                print(p.index)
                p=p.next
            return
    else:
        minn=10000000;
        change=False
        for node_visited in visited: #visited中储存的节点的distance是距离起点的distance
            p=Graph[node_visited.index].next
            while(p):
                check=True
                for visited_check in visited:
                    if p.index==visited_check.index:
                        check=False
                        break;
                if check and p.distance>0 and p.distance+node_visited.distance<minn:
                            #p.distance:p-node_visited
                            #node_visited.distance:node_visited-s
                    minn=p.distance+node_visited.distance
                    node=p
                    pos_node=node_visited.index
                    change=True
                p = p.next
        if change:
            new_node=Node(index=node.index,distance=minn)
            visited.append(new_node)
            visited_routes[new_node.index]=visited_routes[pos_node]+[new_node.index]
            if new_node.index==e:
                for i in range(len(visited_routes[new_node.index])-1):
                    Node_1=Graph[visited_routes[new_node.index][i]]
                    Node_2_index=visited_routes[new_node.index][i+1]
                    p=Node_1.next
                    while(p):
                        if p.index==Node_2_index:
                            total_distance+=p.distance
                            break;
                        p=p.next

                print(f"begin node: {s}")
                print(f"end node: {e}")
                print(f"passing rote: {visited_routes[new_node.index]}")
                print(f"total distance: {total_distance}")
                return;
    Dijkstra_Link(s,e,visited,visited_routes,Graph,total_distance)


def Dijkstra_array_plot(s,visited,visited_distance,M,length_visited_before):
    print(len(visited))
    visited_change=False;
    if len(visited)==1:
        minn=1000000000;
        for j in range(len(M[s])):
            if M[s][j]!=0 and M[s][j]<minn:
                minn=M[s][j];
                node=j
        visited.append(node) #append the node which has been visited
        visited_distance.append(minn) #append the minimum distance between s and node
        visited_change=True
    else:
        minn=100000000;
        node=-1;
        pos_node=-1;
        for j in range(len(M)):
            if j not in visited and j !=s:
                for i in range(len(visited)):
                    if M[visited[i]][j]!=0 and M[visited[i]][j]+visited_distance[i]<minn:
                        minn=M[visited[i]][j]+visited_distance[i];
                        node=j
                        pos_node=visited[i];
        if node!=-1 and pos_node!=-1:# to make sure the node is useful
            visited.append(node)
            visited_distance.append(minn)
            visited_change=True
        if visited_change==False:
            return visited;
        if (length_visited_before+len(visited))==len(M):
            return visited
    Dijkstra_array_plot(s,visited,visited_distance,M,length_visited_before)
    return visited


def Dijkstra_Link_plot(s,visited,Graph,len_visited_before):
    if len(visited) == 1:
        minn = 100000000;
        p = Graph[s];  # set the node
        while (p.next != None):
            p = p.next
            if p.distance < minn:
                minn = p.distance
                node = p;
        visited.append(node)
        #visited_routes[new_node.index]=[s,new_node.index]#store the index and distance
        if len(visited)+len_visited_before==len(Graph):
            return visited
    else:
        minn=10000000;
        change=False
        for node_visited in visited: #visited中储存的节点的distance是距离起点的distance
            p=Graph[node_visited.index].next
            while(p):
                check=True
                for visited_check in visited:
                    if p.index==visited_check.index:
                        check=False
                        break;
                if check and p.distance>0 and p.distance+node_visited.distance<minn:
                            #p.distance:p-node_visited
                            #node_visited.distance:node_visited-s
                    minn=p.distance+node_visited.distance
                    node=p
                    pos_node=node_visited.index
                    change=True
                p = p.next
        if change:
            new_node=Node(index=node.index,distance=minn)
            visited.append(new_node)
            if len(visited)+len_visited_before==len(Graph):
                return visited;
    Dijkstra_Link_plot(s,visited,Graph,len_visited_before)
    return visited