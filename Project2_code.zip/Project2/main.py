from read_file import *
from dijkstra import *
from floyd import *
from plot import *
import time
###run the test case

game_is_on=True
while game_is_on:
    user=input(f'Welcome to Project 2!!!\n'
               f'if you want to use dijkstra algorithm with 2-dimention array,please input 1;\n'
               f'if you want to use dijkstra algorithm with linked list, please input 2;\n'
               f'if you want to use floyd algorithm with 2-dimention array,please input 3;\n'
               f'if you want to use floyd algorithm with linked list, please input 4;\n'
               f'if you want to plot the performance,please input 0!!!'
               f'please remember,it will take a lot of time !!!!!!\n'
               f'if you want to quit,please input other numbers\n');
    if user=='1':
        s = int(input(f'the beginning node:'))
        e = int(input(f'the ending node:'))
        M = read_to_array('Project2_Input_File3.csv')
        visited_routes = {}
        visited_routes[s] = [s]
        Dijkstra_array(s,e, [s], [0], M, visited_routes)
    elif user=='2':
        s = int(input(f'the beginning node:'))
        e = int(input(f'the ending node:'))
        Graph = read_to_link('Project2_Input_File3.csv')
        visited = [Graph[s]]
        visited_routes = {}
        visited_routes[s] = [s]
        Dijkstra_Link(s, e, visited, visited_routes, Graph,0)
    elif user=='3':
        s = int(input(f'the beginning node:'))
        e = int(input(f'the ending node:'))
        M = read_to_array('Project2_Input_File3.csv')
        Floyd_array(M,s,e)
    elif user=='4':
        s = int(input(f'the beginning node:'))
        e = int(input(f'the ending node:'))
        Graph = read_to_link('Project2_Input_File3.csv')
        Floyd_link(Graph, s, e)
    elif user=='0':

        files=['Project2_Input_File1.csv',
               'Project2_Input_File2.csv',
               'Project2_Input_File3.csv',
               'Project2_Input_File4.csv',
               'Project2_Input_File5.csv',
               'Project2_Input_File6.csv',
               'Project2_Input_File7.csv',
               'Project2_Input_File8.csv',
               'Project2_Input_File9.csv',
               'Project2_Input_File10.csv']

        #files=['Project2_Input_File1.csv',
        #       'Project2_Input_File2.csv']
        #files=['Project2_Input_File8.csv']
        user_plot = input(f'Welcome to Project 2 plot system!!!\n'
                     f'if you want to use dijkstra algorithm with 2-dimention array,please input 1;\n'
                     f'if you want to use dijkstra algorithm with linked list, please input 2;\n'
                     f'if you want to use floyd algorithm with 2-dimention array,please input 3;\n'
                     f'if you want to use floyd algorithm with linked list, please input 4;\n'
                     f'please remember,it will take a lot of time !!!!!!\n'
                     f'if you want to quit,please input other numbers\n');
        if user_plot=='1':
            times={}
            for p in range(len(files)):
                start=time.time()
                M = read_to_array(files[p])
                n=len(M)
                visited = Dijkstra_array_plot(0, [0], [0], M,0)
                visit_not_end=True
                while(visit_not_end):
                    if len(visited)==n:
                        visit_not_end=False
                    else:
                        for i in range(n):
                            if i not in visited:
                                length_visited_before=len(visited)
                                visited=visited+Dijkstra_array_plot(i,[i],[0],M,length_visited_before)
                                break;

                end=time.time()
                times[p+1]=round(end-start,2)
                print(f'{p+1}: {times[p+1]}s')
            plot(times,1)
        elif user_plot=='2':
            print('begin!!!!')
            times = {}
            for p in range(len(files)):
                start = time.time()
                Graph = read_to_link(files[p])
                n=len(Graph)
                Dijkstra_Link_plot(0, [Graph[0]], Graph,0)
                visit_not_end = True
                while (visit_not_end):
                    if len(visited) == n:
                        visit_not_end = False
                    else:
                        for i in range(n):
                            if i not in visited:
                                len_visited_before = len(visited)
                                visited = visited + Dijkstra_Link_plot(i, [Graph[i]], Graph,len_visited_before)
                                break;
                end = time.time()
                times[p + 1] = round(end - start, 2)
                print(f'{p + 1}: {times[p + 1]}s')
            plot(times,2)
        elif user_plot=='3':
            times = {}
            for p in range(len(files)):
                start = time.time()
                M = read_to_array(files[p])
                Floyd_array(M, 0, 2)
                end = time.time()
                times[p + 1] = round(end - start, 2)
            plot(times,3)
        elif user_plot=='4':
            times={}
            for p in range(len(files)):
                start=time.time()
                Graph = read_to_link(files[p])
                Floyd_link(Graph,0,2)
                end=time.time()
                times[p+1]=round(end-start,2)
            plot(times,4)


    else:
        print('bye-bye,have a nice day:)')
        game_is_on=False


###plot the performance
#total time to construct the data structure & compute all-pair shortest paths


















